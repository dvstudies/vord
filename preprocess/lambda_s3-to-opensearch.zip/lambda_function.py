import boto3
import json
import requests
from requests.auth import HTTPBasicAuth
import os
from aws_requests_auth.aws_auth import AWSRequestsAuth

s3 = boto3.client('s3')

OPENSEARCH_URL = os.environ['OPENSEARCH_URL']
OPENSEARCH_USER = os.environ['OPENSEARCH_USER']
OPENSEARCH_PASS = os.environ['OPENSEARCH_PASS']


BATCH_SIZE = 25  # Number of documents per bulk call


def lambda_handler(event, context):
    bucket = event.get("bucket")
    key = event.get("key")
    index = event.get("index")

    if not all([bucket, key, index]):
        return { "status": "Error", "message": "Missing input parameters" }

    try:
        s3_obj = s3.get_object(Bucket=bucket, Key=key)
        body = s3_obj["Body"]
    except Exception as e:
        return { "status": "Error", "message": f"S3 read failed: {str(e)}" }

    # Prepare AWS SigV4 auth for OpenSearch
    session = boto3.session.Session()
    credentials = session.get_credentials().get_frozen_credentials()
    region = session.region_name

    auth = HTTPBasicAuth(OPENSEARCH_USER, OPENSEARCH_PASS)
    headers = { "Content-Type": "application/x-ndjson" }

    # Streaming & batching
    success_count = 0
    error_count = 0
    batch = []

    for raw_line in body.iter_lines():
        line = raw_line.decode("utf-8").strip()
        if not line:
            continue
        # Prepare bulk action
        batch.append(json.dumps({ "index": { "_index": index } }))
        batch.append(line)

        if len(batch) >= BATCH_SIZE * 2:  # 2 lines per doc: action + data
            status, ok = send_bulk_request(batch, OPENSEARCH_URL, auth, headers)
            success_count += ok
            error_count += (BATCH_SIZE - ok)
            batch = []

    # Send any remaining batch
    if batch:
        leftover = len(batch) // 2
        status, ok = send_bulk_request(batch, OPENSEARCH_URL, auth, headers)
        success_count += ok
        error_count += (leftover - ok)

    return {
        "status": "Completed",
        "indexed_documents": success_count,
        "failed_documents": error_count
    }

def send_bulk_request(batch_lines, url, auth, headers):
    payload = "\n".join(batch_lines) + "\n"
    res = requests.post(f"{url}/_bulk", auth=auth, headers=headers, data=payload)

    if res.status_code != 200:
        print("OpenSearch error:", res.status_code, res.text)
        return res.status_code, 0

    response = res.json()
    if not response.get("errors"):
        return res.status_code, len(response["items"])

    # Count successes from mixed result
    successes = sum(1 for item in response["items"] if "error" not in item["index"])
    return res.status_code, successes